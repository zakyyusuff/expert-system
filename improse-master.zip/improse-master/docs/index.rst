Improse Documentation
=====================

Welcome to Improse - Integrated Methods for Prediction of Super-Enhancers


Table of Contents
-----------------

.. toctree::
   :maxdepth: 2

   intro
   install
   howto
   support
   cite
   
