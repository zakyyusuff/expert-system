# [Backpropagation](https://maziarraissi.github.io/backprop/) in Python, C++, and Cuda

This is a short tutorial on backpropagation and its implementation in Python, C++, and Cuda. 

Please start by reading the pdf file "backpropagation.pdf".
